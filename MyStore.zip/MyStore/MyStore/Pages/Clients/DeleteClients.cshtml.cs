using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients
{
    public class DeleteClientsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
